import { Delete_form, Submit_form, Update_form } from "../action/List_action";

const initialeState={
    data:[]
}

const ListReducer = (state = initialeState, action) => {

    switch (action.type) {
        case Submit_form:
            return {...state,todos:[...state.data,action.payload]}
        case Update_form:
            return state.map((list) => {
                if (list.id === action.payload.id) {
                    return action.payload
                }
                return list
            })

        case Delete_form:
            return state.filter((list) => list.id !== action.payload.id)
        default: return state;
    }

}
export default ListReducer;