import {combineReducers} from "redux"
import ListReducer from "./List_reducer"

const rootReducer=combineReducers({
   todos: ListReducer
});
export default rootReducer;