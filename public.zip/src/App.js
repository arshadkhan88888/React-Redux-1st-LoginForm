import React from 'react';
import Header from './Components/Header';
import Footer from './Components/Footer';
import "./App.css"



const App = () => {
  return (
    <div className="App_div">
      <Header style={{position:"fixed"}}/>
      
      <hr style={{margin:"80px"}}></hr>

      <Footer style={{position:"fixed"}}/>
    </div>
  );
};

export default App;