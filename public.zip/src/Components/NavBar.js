import React from 'react';
import Shop from './Shop';
import { Link,BrowserRouter as Router, Route,Switch } from 'react-router-dom';
import Home from './Home';
import Loginnn from './Loginnn';

const NavBar = () => {
    return (
        <div  className="nav_main_div">
         <Router>
            <nav className="navbar navbar-light" style={{backgroundColor: "#d9ebf8"}}>
                <img className="logo_div" style={{ marginLeft: "150px" }} src={require("../assets/logo.png")} alt="" />
               
                 
                    <div className="link_div">
                     <Link className="nav-link" to="/Home">HOME</Link>
                     <Link  className="nav-link" to="/Shop">SHOP</Link>
                     <Link  className="nav-link" to="/Product">PRODUCTS</Link>
                     <Link  className="nav-link" to="/Log">LOGIN</Link>
                     <Link  className="nav-link" to="/Register">REGISTER</Link>
                    </div>
                   </nav>
                    <Switch>
                        <Route exact path="/Home" component={Home} />
                        <Route exact path="/Shop" component={Shop} />
                        <Route exact path= "/Log" component={Loginnn}/>
                    </Switch>
                     
            </Router>
</div>
            
     
    );
};

export default NavBar;