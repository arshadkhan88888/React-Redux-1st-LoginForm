import React from 'react';
import loginList from "./loginList"
import Loginn from "./Loginn"
import {BrowserRouter as Router,Link ,Route,Switch} from "react-router-dom";

const Loginnn = () => {
    return (
        <div>
            <Router>
                <Link  to="/Loginn">Login</Link>
                <Link  to="/loginList/">Login List</Link>
                <Switch>
                    <Route  path="/Loginn" component={Loginn} />
                    <Route  path="/loginList/" component={loginList} />
                </Switch>
            </Router>

        </div>
    );
};

export default Loginnn;