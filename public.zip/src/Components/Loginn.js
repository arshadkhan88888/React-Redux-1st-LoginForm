import React, { useState } from 'react';
import { submitForm } from '../action/List_action';
import {connect, useDispatch} from "react-redux"



const Login=()=>{

    const [inp1,setInp1]=useState("")
    const [inp2,setInp2]=useState("")
    

     const dispatch = useDispatch()
    const handlesubmit=()=>{
       
         dispatch(submitForm(inp1,inp2))
    
    }
     
    return (
        <div>
      
       <div >
           <form onSubmit={(e)=>
           handlesubmit(e.preventDefault())
           }>

                <label>Email</label>
                <input type="email" placeholder="enter Email" value={inp1} onChange={(e)=>setInp1(e.target.value)} />

                <label>Password</label>
                <input  type="password" placeholder="enter Password" value={inp2}  onChange={(e)=>setInp2(e.target.value)}/>

                <input type="submit" />
</form>
         </div> 
</div>
    )
};

export default connect()(Login);