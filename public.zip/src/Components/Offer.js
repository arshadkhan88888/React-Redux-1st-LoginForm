import React, { useState } from 'react';



const Offer = () => {
    return (
        <div className="container" style={{position:"relative"}}>
            <div style={{display:"flex",paddingTop:"30px",paddingLeft:"15px",}}>

            <div className="col-6">
           <img className="men" src={require("../assets/images/Men.jpg")} width="300px" height="170px" />
            <h4 className="h4_men">save 30%</h4>
            <h2 className="h2_men">MEN</h2>
          </div>

           <div className="col-lg-6">
            <img className="women"   src={require("../assets/images/Women.jpg")} width="300px" height="170px" />
            <h4 className="h4_women">save 60%</h4>
            <h2  className="h2_women">WOMEN</h2>
            </div>
   </div>
            
        </div>

    );
};

export default Offer;