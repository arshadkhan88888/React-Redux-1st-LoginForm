import React from "react"
import {BrowserRouter as Router,Link,Route,Switch} from "react-router-dom"
import Meals from "./Meals"
import Recipe from "./Recipe"
import Mealstype from "./Mealstype"


const ApiCall=()=>{
return(
        <div className="container">
        
      <div>
      <Router>
      <nav style={{clear:"both",width:"100%",backgroundColor:"red" ,fontSize:"40px",top:"10px"}} class="navbar navbar-expand-lg">
      <Link style={{textAlign:"center"}} exact to="/">Meals</Link>
     
      </nav>
        <Switch>
           <Route exact path="/Recipe/:id" component ={Recipe}/>
           <Route exact path="/" component ={Meals}/>
           <Route exact path="/Mealstype/:id" component ={Mealstype}/>
        </Switch>
      </Router>
      </div>
      </div>
)
}
export default ApiCall;