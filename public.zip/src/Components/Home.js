import React from 'react';

const Home = () => {
    return (
        <div>
            <h2 style={{alignContent:"center",textAlign:"center",width:"100%"}}>Home Page</h2>
        </div>
    );
};

export default Home;