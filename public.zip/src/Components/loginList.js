import React from 'react';
import {connect} from "react-redux"

const loginList=(todos,match)=>{
console.log(todos,match);
    return (
        <div>
            <table className="table table-dark">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {
                       
                          todos.length>0 && todos.map((todo)=>
                            <tr>
                                <td>{todo.inp1}</td>
                                {/* <td>{todo["inp2"]}</td> */}
                            </tr>
                           )
                       
                    }
                </tbody>
            </table>
        </div>

    );
};

const mapStateToProps=state=>({
    todos:state.match.data
})


export default (loginList)