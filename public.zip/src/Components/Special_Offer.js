import React from 'react';
import { Slide } from 'react-slideshow-image';
import 'react-slideshow-image/dist/styles.css'

const image = [
    { imge: "watch.jpg", name: "Watch",class:"New",req:"on sale" },
    { imge: "trimmer.jpg", name: "Trimmer" ,class:"New",req:"on sale"},
    { imge: "t-shirt.jpg", name: "t-shirt" ,class:"New",req:"on sale"},
    { imge: "t-shirt2.jpeg", name: "t-shirt",class:"New" ,req:"on sale"},
    { imge: "pendrive.jpg", name: "pendrive" ,class:"New",req:"on sale"}
]

const Special_Offer = () => {
    return (
        <div className="container">
            <div className="off_div" style={{gridAutoRows: "min-content",gridAutoRows:"20cm"}}>
                <h4 style={{ textAlign: "center", fontSize: "16px" }}>Special Offer</h4>
                <h2 style={{ textAlign: "center", fontSize: "28px" }}>TOP COLLECTION</h2>
                <hr />
                <p>Collection Ethnic Wear - Buy Hir Collection Ethnic Wear at India's Best Online Shopping Store. Check Price in India and Shop Online. ✓ Free Shipping</p>
            </div>

            <div className="col-lg" >
                <div className="col-lg">
                    <Slide>

                        {
                            image.map((ele) =>
                                <div className="each-slide"  style={{ display: "inline-block", margin: "auto" }}>
                                    <div><span style={{ paddingLeft: "-220px" }}>{ele["name"]}</span>
                                    <img src={require(("../assets/images/" + ele["imge"]))} /></div>
                                    <h4>{ele["class"]}</h4>
                                    <h5>{ele["req"]}</h5>
                                </div>
                            )

                        }

                    </Slide>
                </div>
            </div>


        </div>
    );
};

export default Special_Offer;