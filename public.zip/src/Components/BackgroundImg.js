import React from 'react';

const BackgroundImg = () => {
    return (
        <div className="bg_image">
            <div className="container">
                <div className="img_txt">
                    <h2>2020</h2>
                    <h3>FASHION TRENDS</h3>
                    <h4>SPECIAL OFFER</h4>
                </div>
            </div>
        </div>
    );
};

export default BackgroundImg;