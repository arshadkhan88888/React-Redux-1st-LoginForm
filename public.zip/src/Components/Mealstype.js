import React,{useState,useEffect} from "react"
import Axios from "axios"
// import { Link } from "react-router-dom"

const Mealstype=(props)=>{
  const [info2,setInfo2]=useState([])
    useEffect(()=>{
        Axios.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${props.match.params.id}`)
        .then((res)=>{
            setInfo2(res.data.meals)
        })
    },[])
    return(

       
    <div className='container' >
        {
            info2.map((recDetail)=>{
                return(
                   
                 <div  >
                <div className="card-body bg-light" style={{width:"100%",overflow:"auto",paddingTop:"90px"}}>
                <div className="card-body col-md-4">
                 <img className="card-img-top" src={recDetail.strMealThumb} alt='' widht='20px'/>
                 <ul>
                 <li>{recDetail.idMeal}</li>
                 <li>{recDetail.strMeal}</li>
                 <li>{recDetail.strCategory}</li>
                 <li>{recDetail.strMeasure2}</li>
                 <li>{recDetail.strArea}</li>
                 <li>{recDetail.strInstructions}</li>
                 </ul>
                </div>
                </div>
                </div>
                
                )
            })
        }
        </div>
        
        )
    
}
export default Mealstype;