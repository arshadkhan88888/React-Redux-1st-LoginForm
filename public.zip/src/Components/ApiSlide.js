import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import React from 'react';
import Slider from "react-slick"

const khan=[
    {imgPath:"cat1.jpg"},
    {imgPath:"cat2.jpg"},
    {imgPath:"cat3.jpg"},
    {imgPath:"cat4.jpg"},
    {imgPath:"dog1.jpg"},
    {imgPath:"dog2.jpg"},
    {imgPath:"dog3.jpg"},
]

const ApiSlide = () => {
    const setting={
        dots:true,
        fade:true,
        infinite:true,
        speed:50,
        slideToShow:1,
        arrows:true,
        slideToScroll:1,
        className:"slides"
    }
    return (
        
          <div className="container" style={{paddingTop:"50px"}} >
              
              <Slider {...setting}> 
            
              {
                 
                                    khan.map((item)=>
                                    
                                    <div  style={{backgroundColor:"green",clear:"both"}} >
                                    <img  className="card-img" src={require(("../assets/images/" +item["imgPath"]))} width="200px" height="350px"/> 
                                    
                                    </div>
                                    )
                                    
                                    }
                                    
              </Slider>
              <div style={{backgroundColor:"red"}}></div> 
          </div>  
    
    );
};

export default ApiSlide;