import React from 'react';
import { Link, BrowserRouter as Router } from 'react-router-dom';
import NavBar from "./NavBar"
import SearchIcon from "@material-ui/icons/Search";

const Header = () => {
    return (
        <div>
            <Router>
                <div className="head_div">
                   <div className="container">
                   <SearchIcon />
                    <Link className="login_text" to="/">LogIn</Link>
                   </div>
                </div>
            </Router>
            <NavBar/>
           
           
           
        </div>
    );
};

export default Header;