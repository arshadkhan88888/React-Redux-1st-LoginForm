import React,{useState,useEffect} from "react"
import Axios from "axios"
import { Link } from "react-router-dom"

const Recipe=(props)=>{
  const [info1,setInfo1]=useState([])
    useEffect(()=>{
        Axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${props.match.params.id}`)
        .then((res)=>{
            setInfo1(res.data.meals)
        })
    },[])
    return(
        <div>
    <div  style={{overflow:"auto",display:"flex",paddingTop:"20px",fontSize:"18px"}}>
        {
            info1.map((rec)=>{
                return(
                    <>
                 <div className='container'>
                <div className="card-body bg-light">
                <Link to={`/Mealstype/${rec.idMeal}`}><img src={rec.strMealThumb} alt="" width="100%"/></Link>
                
                </div>
                <div>
                <h4 >{rec.idMeal}</h4>
                <h4>{rec.strMeal}</h4>
                </div>
                </div>
                </>
                )
            })
        }
        </div>
        </div>
    )
}
export default Recipe;