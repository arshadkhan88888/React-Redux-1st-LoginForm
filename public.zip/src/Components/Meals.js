import React,{useState,useEffect} from "react"
import Axios from "axios"
import { Link } from "react-router-dom"


const Meals=()=>{
  const [info,setInfo]=useState([])
    useEffect(()=>{
        Axios.get("https://www.themealdb.com/api/json/v1/1/list.php?c=list")
        .then((res)=>{
            setInfo(res.data.meals)
        })
    },[])
    return(
        <>
        
        <div style={{backgroundColor:"#d9ebf8",height:"110px",overflow:"auto",display:"flex",fontSize:"20px"}}>
        {
            info.map((ele)=>{
               
                return <div  className='container'>
                <div className="card-body bg-light"  >
                <Link  to={`/Recipe/${ele.strCategory}`}>{ele.strCategory}</Link>
                </div>
               
                </div>  
          })
         }
        </div>
       
       
        </>
    )
}
export default Meals;