import React from 'react';
import ApiSlide from "./ApiSlide"
import Offer from "./Offer"
import Special_Offer from "./Special_Offer"
import BackgroundImg from "./BackgroundImg"
import ApiCall from "./ApiCall"
const Shop = () => {
    return (
        <div className="container">
        <div style={{width:"100%"}}>
        <ApiSlide/>
      <Offer/>
      <Special_Offer/>
      <BackgroundImg/>
      <ApiCall/>
        </div>
         </div>
    );
};

export default Shop;