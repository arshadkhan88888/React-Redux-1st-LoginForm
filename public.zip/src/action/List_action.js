export const Submit_form="Submit_form"
export const Update_form="Update_form"
export const Delete_form="Delete_form"

export const submitForm=(data)=>{
    return{
        type:Submit_form,
        payload:data,
      
    }
}

export  const updateForm = (data)=>{
    return{
        type:Update_form,
        payload:data,
     
    };
};

export const deleteform=(data)=>{
    return{
        type:Delete_form,
        payload:data,
       
    }
}